# Fashion & Beauty — Resources
- Shoot checklist
- UGC brief template
- Basic ad creative specs by platform
