# Fashion & Beauty — Case Studies (mini)
- GRWM series increased watch time by 29%.
- Drop countdown lifted CTR 1.6x on launch day.
