# Fashion & Beauty — Strategies
- Platform focus: Instagram, TikTok, YouTube
- Content: GRWM, lookbooks, routine breakdowns, “shop the look”
- Tactics: drops calendar, influencer duets, UTM’d bio links
