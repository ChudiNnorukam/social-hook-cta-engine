# Fashion & Beauty — Description
Audience: brands, creators, boutiques. Goals: brand lift, drops, collabs. Angles: trends, how-to, transformations, styling.
