# E-commerce — Description
Audience: DTC and marketplace sellers. Goals: sales, AOV, repeat purchases. Angles: product benefits, UGC, social proof, promos.
