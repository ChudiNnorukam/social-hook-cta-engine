# E-commerce — Strategies
- Platform focus: IG Reels, TikTok, FB/IG Shops
- Content: product demos, UGC, how-to, before/after, bundles
- Tactics: Drops + countdowns, limited-time bundles, influencer UGC, remarketing with UTM tags
