# Travel & Hospitality — Case Studies (mini)
- 48h itineraries boosted saves 2.3x.
- Suite tours raised inquiries 15% week-over-week.
