# Travel & Hospitality — Strategies
- Platform focus: Instagram, YouTube, TikTok
- Content: 48-hour itineraries, property tours, seasonal guides
- Tactics: limited-time bundles, influencer stay, bio link with UTM
