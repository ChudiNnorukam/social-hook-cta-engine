# Travel & Hospitality — Resources
- Itinerary template
- Room tour shot list
- Local partner collaboration sheet
