# Financial Services — Strategies
- Platform focus: LinkedIn, YouTube Shorts, Instagram
- Content: frameworks (50/30/20), visual explainer threads, glossary
- Tactics: weekly Q&A, lead form UTM, compliance review
