# Financial Services — Resources
- Compliance reminder: avoid individualized advice
- Visual template pack pointers
- Lead magnet checklist
