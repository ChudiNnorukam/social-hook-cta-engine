# Health & Wellness — Strategies
- Platform focus: Instagram, TikTok, YouTube Shorts
- Content: quick routines, myth-busting, 7-day challenges, meal preps
- Tactics: serial content (Day 1–7), community Q&A, clear CTA to free guide
