# Health & Wellness — Resources
- Content pillars list
- Prompt bank for routines/how-tos
- Basic compliance reminder: avoid medical claims
