# Real Estate — Resources
- Open house content checklist
- Buyer/seller FAQ prompts
- Local SEO pointers: NAP consistency
