# Real Estate — Strategies
- Platform focus: IG Reels, YouTube Shorts, TikTok
- Content: quick tours, price comps, financing tips, local hotspots
- Tactics: weekly market update, UTM to lead form, DM keyword automation
