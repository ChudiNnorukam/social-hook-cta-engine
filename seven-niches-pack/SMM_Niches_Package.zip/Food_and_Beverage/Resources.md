# Food & Beverage — Resources
- Menu photo checklist
- Shortlist of local community pages
- Allergy/claim disclaimer reminder
