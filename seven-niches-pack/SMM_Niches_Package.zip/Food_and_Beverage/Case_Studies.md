# Food & Beverage — Case Studies (mini)
- Weekday lunch series increased bookings 22%.
- Reviews duet improved saves 1.9x.
