# Food & Beverage — Strategies
- Platform focus: Instagram, TikTok
- Content: fast recipes, plating tips, new menu items
- Tactics: weekday lunch promos, UTM to order page, creator tastings
