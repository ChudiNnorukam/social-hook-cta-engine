Social Hook + CTA Engine — Seven Niches Pack

This pack contains niche-specific guidance and resources for 7 popular SMM niches:
- E-commerce
- Health & Wellness
- Real Estate
- Fashion & Beauty
- Food & Beverage
- Travel & Hospitality
- Financial Services

How to use
1) Open guides in each folder to understand strategy
2) Use sample content calendars and templates as starting points
3) Combine with the free Social Hook tool to generate hooks/CTAs/hashtags
4) Post, track with UTM links, iterate

Version: 1.0.0
Changelog: see CHANGELOG.txt
